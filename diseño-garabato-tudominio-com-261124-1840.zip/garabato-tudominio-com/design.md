# Garabato — sistema visual

## Identidad

Landing de ilustración con lenguaje gráfico de tinta, titulares de cartel y fondo crema. Se conserva la marca y la arquitectura de secciones del archivo de referencia.

## Tipografía

- `display`: Dela Gothic One.
- `sans`: Rubik.
- Los títulos usan escalas fluidas con `clamp(...)` y ajustes de tracking; los párrafos mantienen ancho de lectura limitado y altura de línea amplia.

## Color

- `crema`: `#F2EFE6`.
- `negro`: `#000000`.
- `humo`: `#6B6860`.

El body usa `bg-crema font-sans text-negro antialiased`. Los fondos, botones y links reutilizan los colores del tema; el foco visible está definido en CSS.

## Layout y componentes

- Contenedores observados: `640px`, `1280px`.
- Las secciones alternan grids, espacios amplios y bloques de texto acotados; las imágenes usan proporciones explícitas y `object-cover` cuando corresponde.
- Header con navegación de escritorio y menú móvil; footer con enlaces y datos del negocio. Botones y tarjetas conservan bordes, radios y acentos propios del tema.

## Responsive e interacción

- La navegación cambia en `lg`; las grillas colapsan en mobile y se expanden con los breakpoints `sm`, `md` y `lg` presentes en las clases.
- Menú móvil con JavaScript vanilla. El archivo conserva los estados hover, el foco visible y la preferencia de movimiento reducido ya definidos en el original.