(() => {
const abrir = document.getElementById('menu-abrir');
const cerrar = document.getElementById('menu-cerrar');
const menu = document.getElementById('menu-movil');
if (!abrir || !cerrar || !menu) return;
const estaAbierto = () => !menu.classList.contains('hidden');
const setAbierto = (abierto) => {
menu.classList.toggle('hidden', !abierto);
menu.classList.toggle('flex', abierto);
abrir.setAttribute('aria-expanded', String(abierto));
document.body.classList.toggle('overflow-hidden', abierto);
(abierto ? cerrar : abrir).focus();
};
abrir.addEventListener('click', () => setAbierto(true));
cerrar.addEventListener('click', () => setAbierto(false));
menu.addEventListener('click', (evento) => {
if (evento.target.closest('a')) setAbierto(false);
});
document.addEventListener('keydown', (evento) => {
if (evento.key === 'Escape' && estaAbierto()) setAbierto(false);
});
window.matchMedia('(min-width: 1024px)').addEventListener('change', (evento) => {
if (evento.matches && estaAbierto()) setAbierto(false);
});
})();
(() => {
const ojos = Array.from(document.querySelectorAll('.ojo'));
if (!ojos.length || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
let x = null;
let y = null;
let pendiente = false;
const mirar = () => {
pendiente = false;
ojos.forEach((ojo) => {
const caja = ojo.getBoundingClientRect();
const dx = x - (caja.left + caja.width / 2);
const dy = y - (caja.top + caja.height / 2);
const distancia = Math.hypot(dx, dy) || 1;
const alcance = caja.width * 0.12 * Math.min(1, distancia / 480);
ojo.firstElementChild.style.transform = `translate(${(dx / distancia) * alcance}px, ${(dy / distancia) * alcance}px)`;
});
};
const pedir = () => {
if (x === null || pendiente) return;
pendiente = true;
requestAnimationFrame(mirar);
};
window.addEventListener('pointermove', (evento) => { x = evento.clientX; y = evento.clientY; pedir(); }, { passive: true });
window.addEventListener('scroll', pedir, { passive: true });
})();